package com.project.pw.dao;

import com.project.pw.bean.PaymentBean;
import com.project.pw.exception.PaymentException;

public interface IPaymentDao {
	
	int accCreation(PaymentBean a);
	
	PaymentBean loginUser(int accNo) throws PaymentException;
	
	void updateDetails(int accNo, PaymentBean a);

}
