package com.project.pw.exception;

public class PaymentException extends Exception {

	String message;
	
	public PaymentException(String s) {
		super(s);
	}
	
	public String getMessage()
	{
		return message;
	}
	
	
}
