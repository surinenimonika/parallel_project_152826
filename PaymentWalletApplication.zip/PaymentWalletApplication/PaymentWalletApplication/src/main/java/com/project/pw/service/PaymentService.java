package com.project.pw.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.stream.Stream;

import com.project.pw.bean.PaymentBean;
import com.project.pw.dao.IPaymentDao;
import com.project.pw.dao.PaymentDao;
import com.project.pw.exception.PaymentException;

public class PaymentService implements IPaymentService {
	PaymentBean pbean = new PaymentBean();
	IPaymentDao dao;
	 public PaymentService() {
		 dao = new PaymentDao();
		 
	}
	 LocalDate tDate = LocalDate.now();
	 static String namePattern = "[A-Z]{1}[a-z]{2,10}";
	 static String numberPattern = "[6-9]{1}[0-9]{9}";
	 static String passwordPattern = "[A-Z]{1}[a-z]{2,6}(\\d){1,4}(\\W){1}";
	
	 public  boolean validateCustomerName(String name)
	 {	if(name.matches(namePattern))
	 		return true;
	 	else
	 		return false;
	 }
	 
	 
	 public  boolean validateCustomerPhoneNumber(String number) {
			if(number.matches(numberPattern))
				return true;
			else
				return false;
		}
	 
	 
public boolean validateCustomerAge(int age) {
	if(age<=110&&age>=1)
		return true;
	else
		return false;
	
}

public  boolean validateCustomerPwd(String pwd) {
	if(pwd.matches(passwordPattern))
		return true;
	else
		return false;
}

public  boolean validateAmt(double amt) {
if(amt>0.00)
	return true;
else
	return false;
}

public int addAccDao(PaymentBean a) {
	return dao.accCreation(a);
}

public double depositDao(double money) {
	pbean.setCustomerBal(pbean.getCustomerBal()+money);
	pbean.settDetails("Date :"+tDate+" Depsoited Amount :"+money+" Total Balance :"+pbean.getCustomerBal());
	dao.updateDetails(pbean.getAccNum(),pbean);
	return pbean.getCustomerBal();
}

public double withdrawDao(double money) {
	if(money<pbean.getCustomerBal()) {
		pbean.setCustomerBal(pbean.getCustomerBal()-money);
		pbean.settDetails("Date :"+tDate+" Amount Withdrawn :"+money+" Total Balance :"+pbean.getCustomerBal());
		dao.updateDetails(pbean.getAccNum(),pbean);
		}
		else
			System.out.println(" Low Balance :( ");
		return pbean.getCustomerBal();
}

public double showBalDao() {
	return pbean.getCustomerBal();
}

public boolean checkLogin(int accNo) throws PaymentException {
	pbean =dao.loginUser(accNo);
	if(pbean!=null)
	return true;
	else 
		return false;
}

public boolean checkPassword(String pwd) {
	if(pbean.getCustomerPwd().matches(pwd))
		return true;
	else
		return false;
}

public String currentUser() {
	return pbean.getCustName();
}

public boolean transferAmt(int toAccNo, double money) throws PaymentException {
	PaymentBean ftTemp =new PaymentBean();
	if(pbean.getCustomerBal()>=money) {
	ftTemp = dao.loginUser(toAccNo);
	if(ftTemp!=null)
	{
		ftTemp.setCustomerBal(ftTemp.getCustomerBal()+money);
		pbean.setCustomerBal(pbean.getCustomerBal()-money);
		pbean.settDetails("Date :"+tDate+" Amount Transfered :"+money+" To Acc No: "+ftTemp.getAccNum()+" Total Balance :"+pbean.getCustomerBal());
		ftTemp.settDetails("Date :"+tDate+" Depsoited Amount :"+money+" From Acc No: "+pbean.getAccNum()+" Total Balance :"+ftTemp.getCustomerBal());
		dao.updateDetails(pbean.getAccNum(), pbean);
		dao.updateDetails(ftTemp.getAccNum(), ftTemp);
		return true;
	}
	
	
}
	else if(pbean.getCustomerBal()<money)
	{
		System.out.println("Low Balance to transfer");
	}
	
	else
		System.out.println("No such user account");
	return false;
}

public void printTransdetails() {
	ArrayList<String> tempDetails = new ArrayList<String>();
	tempDetails = pbean.gettDetails();
	Stream printList = tempDetails.stream();
	printList.forEach(System.out::println);
	
}


	
}



