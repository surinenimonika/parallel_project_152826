package com.project.pw.service;

import com.project.pw.bean.PaymentBean;
import com.project.pw.exception.PaymentException;

public interface IPaymentService {

	
	int addAccDao(PaymentBean a);
	double depositDao(double money);
	double withdrawDao(double money) ;
	double showBalDao();
	boolean checkLogin(int accNo) throws PaymentException;
	boolean checkPassword(String pwd);
	String currentUser();
	boolean transferAmt(int toAccNo, double money) throws PaymentException;
	void printTransdetails();
}
