package com.project.pw.dao;

import java.util.TreeMap;

import com.project.pw.bean.PaymentBean;
import com.project.pw.exception.PaymentException;

public class PaymentDao implements IPaymentDao {
	
	TreeMap<Integer, PaymentBean> map = new TreeMap<Integer, PaymentBean>();
	
	public int accCreation(PaymentBean a) {
		a.setAccNum();
		map.put(a.getAccNum(), a);
		return a.getAccNum();
	}

	public PaymentBean loginUser(int accNo) throws PaymentException {
		PaymentBean temp = new PaymentBean();
		
		try {
			temp = map.get(accNo);
			return temp;
				
		}
		catch(NullPointerException e) {
			if(temp==null)
			throw new PaymentException("There is no such Account");
		}
		return null;
	}

	public void updateDetails(int accNo, PaymentBean a) {
		map.replace(accNo, a);
		
	}

}
