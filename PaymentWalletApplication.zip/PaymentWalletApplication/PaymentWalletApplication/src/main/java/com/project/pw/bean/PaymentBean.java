package com.project.pw.bean;

import java.util.ArrayList;

public class PaymentBean {
	
	private int accountNum;
	private String customerName;
	private String customerPhoneNo;
	private int customerAge;
	private double customerBal;
	static private int accountNumGen = 10100;
	private String customerPwd;
	ArrayList<String> list = new ArrayList<String>();
	public ArrayList<String> gettDetails() {
		return list;
	}
	public void settDetails(String getDetails) {
		this.list.add(getDetails);
	}
	public int getAccNum() {
		return accountNum;
	}
	public void setAccNum() {
		this.accountNum = accountNumGen++;
	}
	public String getCustName() {
		return customerName;
	}
	public void setCustName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerPhoneNo() {
		return customerPhoneNo;
	}
	public void setCustomerPhoneNo(String customerPhoneNo) {
		this.customerPhoneNo = customerPhoneNo;
	}
	public int getCustomerAge() {
		return customerAge;
	}
	public void setCustomerAge(int customerAge) {
		this.customerAge = customerAge;
	}
	public double getCustomerBal() {
		return customerBal;
	}
	public void setCustomerBal(double customerBal) {
		this.customerBal = customerBal;
	}
	public String getCustomerPwd() {
		return customerPwd;
	}
	public void setCustomerPwd(String customerPwd) {
		this.customerPwd = customerPwd;
	}
	
	
	
	

}
