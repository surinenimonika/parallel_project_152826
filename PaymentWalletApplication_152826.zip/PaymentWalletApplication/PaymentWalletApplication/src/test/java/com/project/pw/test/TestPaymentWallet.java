package com.project.pw.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.project.pw.bean.PaymentBean;
import com.project.pw.dao.PaymentDao;
import com.project.pw.exception.PaymentException;
import com.project.pw.service.PaymentService;

import junit.framework.Assert;

public class TestPaymentWallet {

	@Test
	public void testValidatePhoneNo() {
		PaymentService check = new PaymentService();
	
	Assert.assertEquals(true, check.validateCustomerPhoneNumber("9874563210"));
		
	}
	
	@Test
	public void testValidateName() {
		PaymentService check = new PaymentService();
	
	Assert.assertEquals(true, check.validateCustomerName("Peter Parker"));
		
	}
	
	@Test
	public void testValidatePwd() {
		PaymentService check = new PaymentService();
	
	Assert.assertEquals(true, check.validateCustomerPwd("Abcd123@"));
		
	}

	@Test
	public void testValidateAge()
	{
		PaymentService check = new PaymentService();
		Assert.assertEquals(true, check.validateCustomerAge(34));
	}
	
	@Test
	public void testValidateAmt()
	{
		PaymentService check = new PaymentService();
		Assert.assertEquals(true, check.validateAmt(2000.00));
	}
	@Test
	public void testValidatePhoneNoFail() {
		PaymentService check = new PaymentService();
	
	assertEquals(false, check.validateCustomerPhoneNumber("8745621212121"));
		
	}
	
	@Test
	public void testValidateNameFail() {
		PaymentService check = new PaymentService();
	
	Assert.assertEquals(false, check.validateCustomerName("Matt123"));
		
	}
	
	@Test
	public void testValidatePwdFail() {
		PaymentService check = new PaymentService();
	
	Assert.assertEquals(false, check.validateCustomerPwd("@! SAm.IY"));
		
	}

	@Test
	public void testValidateAgeFail()
	{
		PaymentService check = new PaymentService();
		Assert.assertEquals(false, check.validateCustomerAge(152));
	}
	
	@Test
	public void testValidateAmtFail()
	{
		PaymentService check = new PaymentService();
		Assert.assertEquals(false, check.validateAmt(0.00));
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void testAccCreation()
	{
		PaymentDao w = new PaymentDao();
		PaymentBean a = new PaymentBean();
		Assert.assertEquals(10100,w.accCreation(a));
		PaymentBean a1 = new PaymentBean();
		Assert.assertEquals(10101,w.accCreation(a1));
		PaymentBean a2 = new PaymentBean();
		Assert.assertEquals(10102,w.accCreation(a2));
		
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void testDepositAmt()
	{
		PaymentService w = new PaymentService();
		PaymentBean a = new PaymentBean();
		Assert.assertEquals(2000.00, w.depositDao(2000.00));
		Assert.assertEquals(4000.00, w.depositDao(2000.00));
		
	}
	@SuppressWarnings("deprecation")
	@Test
	public void testWithdrawAmt() throws Exception
	{
		PaymentService w = new PaymentService();
		PaymentBean a = new PaymentBean();
		
		Assert.assertEquals(4000.00, w.depositDao(4000.00));
		Assert.assertEquals(2000.00, w.withdrawDao(2000.00));
		Assert.assertEquals(00.00, w.withdrawDao(2000.00));
		
	}
	
	@Test
	public void testDispBal()
	{
		PaymentService w = new PaymentService();
		PaymentBean a = new PaymentBean();
		Assert.assertEquals(0.00,w.showBalDao());
		
		
	}
	
	@Test
	public void testLogin() throws PaymentException
	{
		PaymentDao w = new PaymentDao();
		PaymentBean a = new PaymentBean();
		w.accCreation(a);
		PaymentBean a1 = new PaymentBean();
		w.accCreation(a1);
		PaymentBean a2 = new PaymentBean();
		w.accCreation(a2);
		PaymentBean a3 = new PaymentBean();
		w.accCreation(a3);
		System.out.println(a3.getAccNum());
		Assert.assertEquals(a1, w.loginUser(10104));
	}
}
